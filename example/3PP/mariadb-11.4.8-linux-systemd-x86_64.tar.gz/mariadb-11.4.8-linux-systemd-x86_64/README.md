MariaDB (fixture de test)
