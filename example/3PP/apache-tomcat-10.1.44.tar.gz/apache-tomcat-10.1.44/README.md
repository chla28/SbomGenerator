Apache Tomcat (fixture de test)
