MongoDB (fixture de test)
