mongosh (fixture de test)
